import React from 'react';
import Box from "@mui/material/Box";

const Report = () => {
    return (
        <div>
            
        </div>
    );
};

export default Report;