import { combineReducers } from 'redux';
import { configureStore } from '@reduxjs/toolkit';
import LocationMovieDropDownSlice  from "../Slices/MasterSlice/LocationSlice/LocationMovieDropDown"
import MoviesTableGetAllSlice from '../Slices/MasterSlice/MovieSlice/MoviesTableGetAll';
import LocationTableGetAllSlice from '../Slices/MasterSlice/LocationSlice/LocationTableGetAll';
import CategoryTableGetAllSlice from '../Slices/MasterSlice/CategorySlice/CategoryTableGetAll';
import SubCategoryTableSlice from '../Slices/MasterSlice/SubCategorySlice/SubCategoryTable';
import CrewTableGetAllSlice from '../Slices/MasterSlice/CrewSlice/CrewTableGetAll';



// import PrlLoadNoDropDownSlice from "../slices/AddNewParcel/PrlLoadNoDropDown";
// import PrlIdCardDropDownSlice from "../slices/AddNewParcel/PrlIdCardDropDown";


const reducer = combineReducers({

  // PrlLoadNoDropDown: PrlLoadNoDropDownSlice,
  // PrlIdCardDropDown:PrlIdCardDropDownSlice,
  LocationMovieDropDown:LocationMovieDropDownSlice,
  MoviesTableGetAll:MoviesTableGetAllSlice,
  LocationTableGetAll:LocationTableGetAllSlice,
  CategoryTableGetAll:CategoryTableGetAllSlice,
  SubCategoryTable:SubCategoryTableSlice,
  CrewTableGetAll:CrewTableGetAllSlice,
});

const store = configureStore({
	reducer,
});
export default store;
