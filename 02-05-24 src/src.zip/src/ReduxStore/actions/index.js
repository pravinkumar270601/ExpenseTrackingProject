
// import { RptLoadNoDropDownAction } from "../slices/Reports/RptLoadNoDropDown";
import { CategoryTableGetAllAction } from "../Slices/MasterSlice/CategorySlice/CategoryTableGetAll";
import { CrewTableGetAllAction } from "../Slices/MasterSlice/CrewSlice/CrewTableGetAll";
import { LocationMovieDropDownAction } from "../Slices/MasterSlice/LocationSlice/LocationMovieDropDown";
import { LocationTableGetAllAction } from "../Slices/MasterSlice/LocationSlice/LocationTableGetAll";
import { MoviesTableGetAllAction } from "../Slices/MasterSlice/MovieSlice/MoviesTableGetAll";
import { SubCategoryTableAction } from "../Slices/MasterSlice/SubCategorySlice/SubCategoryTable";



const actions = {

  // ...RptLoadNoDropDownAction,
  // ...RptStatusDropDownAction,
  ...LocationMovieDropDownAction,
  ...MoviesTableGetAllAction,
  ...LocationTableGetAllAction,
  ...CategoryTableGetAllAction,
  ...SubCategoryTableAction,
  ...CrewTableGetAllAction,

};

export default actions;
