export const MovieTableHeaders = [
  "S.no",
  "MovieName",
  "Staus",
  "CreatedDate",
  "Actions",
];

export const LocationTableHeaders = [
  "S.no",
  "Movie Name",
  "Location",
  "Created Date",
  "Actions",
];
export const CategoryTableHeaders = [
  "S.no",
  "Movie Name",
  "Category",
  "Created Date",
  "Actions",
];
export const SubCategoryTableHeaders = [
  "S.no",
  "Movie Name",
  "Category",
  "Sub Category",
  "Created Date",
  "Actions",
];
export const CrewTableHeaders = [
  "S.no",
  "Movie Name",
  "Location",
  "Category",
  "Sub Category",
  "Crew Name",
  "Gender",
  "Mobile Number",
  "Nationality",
  "Created Date",
  "Actions",
];

export const TableVaues = [
  {
    "Sno": "1",
    "MovieName": "Thalaiva",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
    
  },
  {
    "Sno": "2",
    "MovieName": "Thalaiva",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
    
  },
  {
    "Sno": "3",
    "MovieName": "Thalaiva",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
    
  },
  {
    "Sno": "4",
    "MovieName": "Thalaiva",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "S.no": "5",
    "MovieName": "Thalaiva",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "6",
    "MovieName": "Thalaiva",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "7",
    "MovieName": "Thalaiva",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "8",
    "MovieName": "Thalaiva",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "9",
    "MovieName": "raja",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "10",
    "MovieName": "Gilli",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "11",
    "MovieName": "Billa",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "12",
    "MovieName": "singam",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "13",
    "MovieName": "Thuppaki",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "14",
    "MovieName": "manjummal boys",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "15",
    "MovieName": "Ayan",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "16",
    "MovieName": "varisu",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "17",
    "MovieName": "premalu",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
  {
    "Sno": "18",
    "MovieName": "padaiyappa",
    "Staus": "completed",
    "CreatedDate": "19-09-2023",
  },
];